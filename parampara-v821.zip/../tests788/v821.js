const pup=require(process.env.PUPPETEER);const fs=require('fs');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const BOOK=JSON.stringify(JSON.parse(fs.readFileSync('/tmp/bk/parampara-data.json','utf8')).db);
const b=await pup.launch({headless:'new',executablePath:process.env.CHROME,args:['--no-sandbox']});
const p=await b.newPage();p.on('pageerror',e=>console.log('ERR',e.message));await p.setRequestInterception(true);
p.on('request',r=>{const u=r.url();(u.startsWith('file:')||u.startsWith('data:'))?r.continue():r.abort().catch(()=>{});});
await p.evaluateOnNewDocument(s=>{ if(!sessionStorage.getItem('seeded')){localStorage.setItem('pb_ob_v1',s);sessionStorage.setItem('seeded','1');} },BOOK);
await p.setViewport({width:420,height:900});await p.goto('file://'+process.env.APP);await sleep(2500);
const fns=["jobWork()","karigarMaster()","karigarEdit()","karigarEdit(DB.karigars&&DB.karigars[0]&&DB.karigars[0].id)","karIssue()","karReceive()","karigarBook()","payList('in')","payList('out')","payEntry('in',1)","payLoan('in')","ledgerMaster()","dayBook()","qrManage()","settingsMenu()","manageExpHeads()","staffHub()","partyStatement()","gstReport()","editCustomer('new')","invoices&&0"];
for(const f of fns){try{await p.evaluate(f);}catch(e){console.log('skip',f,e.message.slice(0,40));continue;}await sleep(500);
 const r=await p.evaluate(()=>{const sh=document.querySelector('#sheet');return [...sh.querySelectorAll('button')].filter(x=>x.offsetParent&&(x.textContent||'').trim()==='✕').length});
 console.log(r>1?'DOUBLE':'ok',r,f);}
// check the flag still reset via shell X
await p.evaluate("_karAfterAdd={oid:'x',gid:'y'};karigarEdit()");await sleep(400);
await p.evaluate("sheetClose()");await sleep(300);console.log('flag after shell X:',await p.evaluate("String(_karAfterAdd)"));
await b.close();})();
